package GuiFx;


/**
 *
 * @author leopoldmols
 */

public enum PlayerFX
{
    HUMAN,
    BOT1,
    BOT2,
    BOT3;
}
