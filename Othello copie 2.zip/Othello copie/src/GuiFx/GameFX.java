package GuiFx;

import Models.Game;
import javafx.geometry.Insets;
import javafx.scene.layout.VBox;


/**
 *
 * @author leopoldmols
 */

public class GameFX extends VBox
{
    private final Game game;
    private final BoardFX board;
    
    public GameFX ()
    {
        this.game = new Game();
        this.board = new BoardFX(this.game);
        
        displayView();
    }
    
    public void displayView ()
    {
        this.setPadding(new Insets(10));
        this.getChildren().add(board);
    }
    
    public Game getGame()
    {
        return game;
    }

    public BoardFX getBoard()
    {
        return board;
    }
}
