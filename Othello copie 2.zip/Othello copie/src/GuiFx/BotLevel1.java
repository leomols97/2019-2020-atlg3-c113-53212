package GuiFx;

/**
 *
 * @author leopoldmols
 */
public class BotLevel1
{
    
}
