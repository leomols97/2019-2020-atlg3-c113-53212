package GuiFx;

import javafx.scene.shape.Rectangle;

/**
 *
 * @author leopoldmols
 */
public class playerInfos
{
    public playerInfos (Rectangle rectangle)
    {
        
    }
}
