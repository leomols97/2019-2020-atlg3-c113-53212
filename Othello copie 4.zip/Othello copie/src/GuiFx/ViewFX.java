package GuiFx;

import Models.*;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.control.Menu;
import javafx.scene.layout.*;


/**
 *
 * @author leopoldmols
 */

public class ViewFX extends VBox implements Observer
{
    private HBox up; // Contains all the players details 
    private HBox middle; // Contains the board and the historic
    private HBox down; // Contains the buttons and the game progressions
    private VBox progressionsAndButtons; // The buttons and progressions under the game
    private HBox HBCompletion; // The infos of the completion of the game
    private HBox HBCurrentWinner; // All the infos about the current winner
    private Label lblCompletion; // The point at which the game is finished
    // The ratio of more whites or black pieces on the playing board
    private Label lblCurrentWinner;
    private GameFX game;
    // La vue du menu d'enregistrement des joueurs
    private MenuView menuView;
    private ButtonsFX buttons;
    private ProgressIndicator gameProgression;
    // La barre de progression qui montre
    // le joueur qui gagne pour le moment
    private RatioBlackAndWhite currentWinner;
    private Button play;
    private WhitePlayerInfos whitePlayerInfos;
    private BlackPlayerInfos blackPlayerInfos;
    private HistoricView historicView;
    private final MenuBar menuBar; // Shows a menu bar at the top of the window
    private final VBox VBoxMenuBar;
    private final Menu menu;
    
    /**
     *
     * @param game
     */
    
    public ViewFX (Model game)
    {
        this.menu = new Menu("Othello");
        this.menuBar = new MenuBar();
        this.VBoxMenuBar = new VBox();
        this.up = new HBox();
        this.lblCurrentWinner = new Label("Partage NOIRS/BALNCS ");
        this.lblCompletion = new Label("Jeu complété à ");
        this.middle = new HBox();
        this.down = new HBox();
        this.progressionsAndButtons = new VBox();
        this.HBCompletion = new HBox();
        this.HBCurrentWinner = new HBox();
        this.game = new GameFX(game);
        this.menuView = new MenuView();
        this.historicView = new HistoricView(game);
        this.buttons = new ButtonsFX(menuView);
        this.gameProgression = new ProgressIndicator();
        this.currentWinner = new RatioBlackAndWhite(game);
        this.play = new Button("Jouer");
        this.whitePlayerInfos = new WhitePlayerInfos(this.game.getGame(), this.menuView);
        this.blackPlayerInfos = new BlackPlayerInfos(this.game.getGame(), this.menuView);
        
        displayView();
        addMenu();
    }
    
    /**
     *
     */
    public void displayView ()
    {
        this.play.setDisable(true);
        this.menuView.getMenu().setGameVisible(true);
        this.menuBar.getMenus().add(menu);
        //MenuItem partie = new MenuItem("Partie");
        
        Menu partie = new Menu("Partie");
        MenuItem jouer = new MenuItem("Jouer");
        MenuItem scoreActuel = new MenuItem("Score actuel");
        partie.getItems().add(jouer);
        partie.getItems().add(scoreActuel);
        menu.getItems().add(partie);
        
        this.VBoxMenuBar.getChildren().addAll(this.menuBar);
        
        this.getChildren().add(VBoxMenuBar);
        
        jouer.setOnAction(e ->
        {
            this.play.setDisable(false);
            this.menuView.getMenu().setGameVisible(false);
        });
        scoreActuel.setOnAction(e ->
        {
            this.buttons.displayActualScore(game.getGame());
        });
        
        this.setPadding(new Insets(10));
        
        play.setMaxWidth(Double.MAX_VALUE);
        GridPane.setHalignment(play, HPos.CENTER);
        GridPane.setHalignment(buttons, HPos.CENTER);
        
        this.play.setOnAction((event) ->
        {
            beginGame();
            addAll(false);
        });
        
        this.buttons.getActualScore().setOnAction((event) ->
        {
            this.buttons.displayActualScore(game.getGame());
        });
        
        this.buttons.getPass().setOnAction((event) ->
        {
            this.game.getGame().changePlayer();
            //this.buttons.noStrikesLeft(game.getGame());
        });
        
        this.buttons.getAbandon().setOnAction((event) ->
        {
            this.play.setDisable(false);
            this.buttons.displayEndGame(game.getGame());
            Game game = new Game(true);
            this.game = new GameFX(game);
            whitePlayerInfos.reInit(game);
            game.initialize();
        });
        
        this.buttons.getRestart().setOnAction((event) ->
        {
            addAll(true);
            //addAll(false);
            //restartGame();
        });
        
        displayGameProgression();
    }
    
    private void addMenu ()
    {
        this.getChildren().addAll(menuView, play);
    }
    
    
    /**
     * Adds everything in the window or remove only the board and the historic
     *
     * @param remove if false, the method only adds everything,
     * and else, removes the board and the historic
     */
    
    private void addAll (boolean remove)
    {
        if (!remove)
        {
            this.HBCompletion.setAlignment(Pos.BOTTOM_CENTER);
            this.HBCurrentWinner.setAlignment(Pos.CENTER);
            this.game.setAlignment(Pos.BOTTOM_LEFT);
            this.whitePlayerInfos.setAlignment(Pos.CENTER_LEFT);
            this.blackPlayerInfos.setAlignment(Pos.CENTER_LEFT);
            this.buttons.setAlignment(Pos.CENTER);
            this.up.setAlignment(Pos.CENTER);
            
            this.HBCompletion.getChildren().addAll(lblCompletion, gameProgression);
            this.HBCurrentWinner.getChildren().addAll(lblCurrentWinner, currentWinner);
            this.up.getChildren().addAll(
                    whitePlayerInfos,
                    blackPlayerInfos
            );
            this.middle.getChildren().addAll(
                    game,
                    historicView
            );
            this.progressionsAndButtons.getChildren().addAll(
                    HBCompletion,
                    HBCurrentWinner,
                    buttons
            );
            this.down.setAlignment(Pos.CENTER);
            this.down.getChildren().add(progressionsAndButtons);
            this.getChildren().addAll(up, middle, down);
        }
        else
        {
            this.middle.getChildren().clear();
            restartGame(this.game.getGame());
        }
    }
    
    private void restartGame (Model game)
    {
        displayGameProgression();
        this.play.setDisable(false);
        this.menuView.clickOnRestartButton();
        
        this.middle.getChildren().clear();
        
        this.game = new GameFX(game);
        //this.historicView = new HistoricView(game);
        this.game.getBoardFX().resetBoard(game);
        this.whitePlayerInfos = new WhitePlayerInfos(this.game.getGame(), this.menuView);
        this.blackPlayerInfos = new BlackPlayerInfos(this.game.getGame(), this.menuView);
        
        this.middle.getChildren().addAll(
                this.game//,
                //historicView
        );
    }
    
    private void beginGame ()
    {
        this.play.setDisable(true);
        this.menuView.clickOnPlayButton();
    }
    
    /**
     *
     * @return
     */
    public GridPane displayGameProgression ()
    {
        GridPane GPScore = new GridPane();
        
        double progression = (this.game.getGame().getNbPieces() / this.game.getGame().getNbCases());
        
        if (progression == 1)
        {
            Button ok = new Button("Ok");
            ok.setMaxWidth(Double.MAX_VALUE);
            GPScore.setHalignment(ok, HPos.CENTER);
            GPScore.setValignment(ok, VPos.CENTER);
            this.buttons.displayActualScore(this.game.getGame());
        }
        this.gameProgression.setProgress(progression);
        return GPScore;
    }
    
    /**
     *
     * @return
     */
    public MenuView getMenuView ()
    {
        return menuView;
    }
    
    /**
     *
     * @return
     */
    public GameFX getGameFX ()
    {
        return this.game;
    }

    /**
     *
     * @return
     */
    public ButtonsFX getButtons()
    {
        return buttons;
    }

    /*public HistoricView getHistoricView()
    {
        return historicView;
    }*/
    
    /**
     *
     */
    @Override
    public void update ()
    {
        displayGameProgression();
        blackPlayerInfos.update();
        whitePlayerInfos.update();
    }
}