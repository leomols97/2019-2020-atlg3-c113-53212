package GuiFx;

import javafx.scene.shape.Circle;
import Models.*;

/**
 *
 * @author leopoldmols
 */
class PieceFX extends Circle
{
    private Piece piece;
    
    public PieceFX (int row, int column)
    {
        this.piece = piece;
    }
}