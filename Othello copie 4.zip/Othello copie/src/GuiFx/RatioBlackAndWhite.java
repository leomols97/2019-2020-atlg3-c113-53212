package GuiFx;

import Models.*;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.paint.Color;


/**
 *
 * @author leopoldmols
 */

public class RatioBlackAndWhite extends ProgressIndicator implements Observer
{
    private final Model game;
    
    public RatioBlackAndWhite(Model game)
    {
        this.game = game;
    }
    
    @Override
    public void update()
    {
        double black = 0.0;
        double white = 0.0;
        if (this.game.getCurrent().getColor().equals(Color.BLACK))
        {
            black = (double) game.getScore(game.getCurrent().getColor());
            white = (double) game.getScore(game.getOponent().getColor());
        }
        else
        {
            black = (double) game.getScore(game.getOponent().getColor());
            white = (double) game.getScore(game.getCurrent().getColor());
        }
        setProgress((black + white) / 64.0);
    }
}