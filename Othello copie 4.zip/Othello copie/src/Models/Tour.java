package Models;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author leopoldmols
 */
public class Tour
{

    private SimpleStringProperty id;
    private SimpleStringProperty name;
    private SimpleStringProperty action;
    private SimpleStringProperty row;
    private SimpleStringProperty column;
    private SimpleStringProperty nbPrises;

    /**
     *
     * @param id
     * @param name
     * @param action
     * @param row
     * @param column
     * @param nbPrises
     */
    public Tour(int id,
            String name,
            Action action,
            int row,
            int column,
            int nbPrises)
    {
        this.id = new SimpleStringProperty("" + id);
        this.name = new SimpleStringProperty(name);
        this.action = new SimpleStringProperty(action.toString());
        this.row = new SimpleStringProperty("" + row);
        this.column = new SimpleStringProperty(column + "");
        this.nbPrises = new SimpleStringProperty("" + nbPrises);
    }

    /**
     *
     * @return
     */
    public String getId()
    {
        return id.get();
    }
    
    /**
     *
     * @return
     */
    public String getName()
    {
        return name.get();
    }

    /**
     *
     * @return
     */
    public String getAction()
    {
        return action.get();
    }

    /**
     *
     * @return
     */
    public String getRow() {
        return row.get();
    }

    /**
     *
     * @return
     */
    public String getColumn() {
        return column.get();
    }

    /**
     *
     * @return
     */
    public String getNbPrises() {
        return nbPrises.get();
    }

}