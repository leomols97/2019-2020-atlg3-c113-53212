package GuiFx;

import Models.*;
import java.util.Observable;
import java.util.Observer;
import javafx.geometry.*;
import javafx.scene.layout.*;

/**
 *
 * @author leopoldmols
 */
public class ViewFX extends VBox implements Observer
{
    Game game;
    BoardFX board;
    ButtonsFX buttons;
    VBox fenetre;
    
    public ViewFX(Game game)
    {
        this.fenetre = new VBox();
        this.game = game;
        this.buttons = new ButtonsFX();
        this.board = new BoardFX(game);
        
        GridPane.setHalignment(buttons, HPos.CENTER);
        fenetre.getChildren().addAll(
                board,
                buttons);
        
        fenetre.setPadding(new Insets(10));
        //this.fenetre.getChildren().add(board);
    }
    
    @Override
    public void update(Observable o, Object arg)
    {
        this.board.update(board, game);
        this.fenetre.getChildren().add(board);
        /*board.updat  car board est un observer
                puis :     
        this.fenetre.getChildren().addAll(board);
*/
    }
}