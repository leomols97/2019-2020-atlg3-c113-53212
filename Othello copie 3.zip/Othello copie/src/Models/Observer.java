package Models;

/**
 * This class represents the Observer.
 *
 * @author leopoldmols
 */
public interface Observer
{
    void update();
}
